-- SWBot Bootstrap (AnkuLua) — Minimal start to ensure logging works
-- Screen: 448x252, 160 DPI

-- CONFIG
local DEBUG_VISUALS = true

-- Early logger to capture any startup errors
local __early_logfile = nil
local __early_logpath = "/storage/emulated/0/log_stage01_guest.log"
pcall(function()
	-- truncate on start
	local f = io.open(__early_logpath, "w")
	if f then
		f:write("[EARLY INIT] " .. os.date() .. "\n")
		f:flush()
		f:close()
	end
	__early_logfile = io.open(__early_logpath, "a")
end)

local function __early(msg)
	pcall(function()
		if __early_logfile then
			__early_logfile:write(msg .. "\n")
			__early_logfile:flush()
		end
	end)
end

__early("BOOT:M0 loaded")

-- Main logger
local logFile = nil
local chosenLogPath = nil

local function initLogger()
	local fileName = "log_stage01_guest.log"
	local candidates = { "/storage/emulated/0/" }
	for _, dir in ipairs(candidates) do
		local path = dir
		if string.sub(path, -1) ~= "/" then path = path .. "/" end
		local full = path .. fileName
		local ok = pcall(function()
			local f = io.open(full, "a")
			if f then
				f:write(string.format("[INIT] %s\n", os.date()))
				f:flush()
				f:close()
			end
		end)
		if ok then
			pcall(function() logFile = io.open(full, "a") end)
			if logFile then
				chosenLogPath = full
				break
			end
		end
	end
	if (not logFile) and __early_logfile then
		logFile = __early_logfile
		chosenLogPath = __early_logpath
	end
end

local function logLine(msg)
	local line = string.format("[%s] %s", os.date("%H:%M:%S"), tostring(msg))
	if logFile then pcall(function() logFile:write(line .. "\n") end); pcall(function() logFile:flush() end) end
	pcall(function() print(line) end)
	if (not logFile) and __early_logfile then
		pcall(function() __early_logfile:write(line .. "\n") end)
		pcall(function() __early_logfile:flush() end)
	end
end

-- Persistent HUD in top-left
local hudId = nil
local function ensureHUD()
	pcall(function()
		if not hudId and createHUD then
			hudId = createHUD()
			if hudSetPosition then hudSetPosition(hudId, 0, 0) end
			if hudMove then hudMove(hudId, 0, 0) end
			if hudShow then hudShow(hudId) end
		end
	end)
end

local function setHUD(text)
	ensureHUD()
	pcall(function()
		if hudId and hudSetText then hudSetText(hudId, tostring(text)) end
		if hudShow then hudShow(hudId) end
	end)
	pcall(function() toast(tostring(text)) end)
end

local function showBootHUD()
	setHUD("SWBot boot")
end

-- Helpers for images and clicking
local IMG_DIR = nil

local function fileExists(path)
	local ok, f = pcall(function() return io.open(path, "rb") end)
	if ok and f then f:close(); return true end
	return false
end

local function resolveImgDir()
	local candidates = {}
	-- Prefer explicit shared-folder path first
	table.insert(candidates, "/storage/emulated/0/$MuMuSharedFolder/SWBot/images/swbot_main/")
	table.insert(candidates, "/storage/emulated/0/SWBot/images/swbot_main/")
	pcall(function()
		if scriptPath then
			local okp, sp = pcall(function() return scriptPath() end)
			if okp and sp and tostring(sp) ~= "" then
				table.insert(candidates, sp .. "../images/swbot_main/")
				table.insert(candidates, sp .. "images/swbot_main/")
			end
		end
	end)
	-- Fallbacks
	table.insert(candidates, "/sdcard/$MuMuSharedFolder/SWBot/images/swbot_main/")
	table.insert(candidates, "/sdcard/AnkuLua/images/swbot_main/")
	for _, dir in ipairs(candidates) do
		if fileExists(dir .. "btn_16_or_older.png") then return dir end
	end
	return candidates[1]
end

local function setImagesPath()
	IMG_DIR = resolveImgDir()
	logLine("IMG_DIR: " .. tostring(IMG_DIR))
	pcall(function() setImagePath(IMG_DIR) end)
	local names = {
		"btn_16_or_older.png",
		"btn_click_all.png",
		"btn_game_start.png",
		"facebook_icon_login_screen.png",
		"guest_icon_login_screen.png",
		"yes_after_selecting_guest_acc.png",
		"advertisement_at_entrance_1.png",
		"advertisement_at_entrance_2.png",
		"touch_to_start.png",
		"touch_to_start_1.png",
		"skip.png",
		"Input.png",
		"EnterNameDONE.png",
		"EnterNameOK.png",
		"DialSkipSX.png",
		"DialSkipDX.png",
	}
	for _, n in ipairs(names) do
		local okp = fileExists((IMG_DIR or "") .. n)
		logLine("TEMPLATE " .. n .. " exists: " .. tostring(okp))
	end
end

local function highlightTap(x, y)
	if not DEBUG_VISUALS then return end
	pcall(function()
		local r = Region(x - 14, y - 14, 28, 28)
		r:highlight(0.30)
	end)
end

local function clickMatch(m)
	-- Compute center
	local cx, cy = nil, nil
	pcall(function()
		if m and m.getTarget then
			local loc = m:getTarget()
			if loc and loc.getX and loc.getY then cx = loc:getX(); cy = loc:getY() end
		end
		if (not cx) and m and m.getCenter then
			local loc = m:getCenter()
			if loc and loc.getX and loc.getY then cx = loc:getX(); cy = loc:getY() end
		end
	end)
	if (not cx) or (not cy) then
		pcall(function()
			if m and m.x and m.y and m.w and m.h then
				cx = m.x + math.floor(m.w/2)
				cy = m.y + math.floor(m.h/2)
			end
		end)
	end
	if cx and cy then
		-- Visualize first, then click
		highlightTap(cx, cy)
		pcall(function() wait(0.10) end)
		logLine("Click at (" .. tostring(cx) .. ", " .. tostring(cy) .. ")")
		pcall(function() click(Location(cx, cy)) end)
		return true
	else
		logLine("ClickMatch: could not compute center")
		return false
	end
end

local function highlightScan(region)
	if not DEBUG_VISUALS then return end
	pcall(function() if region and region.highlight then region:highlight(0.12) end end)
end

local function makePattern(name, sim)
	local pat = nil
	pcall(function() pat = Pattern(name):similar(sim or 0.80) end)
	return pat
end

local function handleServerSelection(FULL, pSrvEmpty, pSrvChecked, pOk, _)
	setHUD("Server: ensure Europe")
	local W, H = 448, 252
	local listR = Region(math.floor(W*0.05), math.floor(H*0.15), math.floor(W*0.40), math.floor(H*0.65))
	if DEBUG_VISUALS then pcall(function() listR:highlight(0.12) end) end

	-- Find Europe text with multi-sim search
	local mEU, euLocX, euLocY = nil, nil, nil
	local sims = {0.92, 0.88, 0.85, 0.80}
	for _, s in ipairs(sims) do
		local okEU, cand = pcall(function() return listR:exists(Pattern("srv_europe_text.png"):similar(s), 0.35) end)
		if okEU and cand then mEU = cand; break end
	end
	if mEU then
		pcall(function()
			local loc = mEU.getCenter and mEU:getCenter() or (mEU.getTarget and mEU:getTarget() or nil)
			if loc and loc.getX and loc.getY then euLocX, euLocY = loc:getX(), loc:getY() end
		end)
	else
		logLine("Server: Europe text not found; cannot verify selection")
		return false
	end
	logLine("Server: Europe text at (" .. tostring(euLocX) .. "," .. tostring(euLocY) .. ")")

	-- Define a small checkbox box to the left of Europe text (row-local)
	local cbW, cbH = 30, 26
	local cbX = math.max(0, (euLocX or 0) - 40)
	local cbY = math.max(0, (euLocY or 0) - math.floor(cbH/2))
	local cbR = Region(cbX, cbY, cbW, cbH)
	if DEBUG_VISUALS then pcall(function() cbR:highlight(0.15) end) end

	-- Always click Europe text first, then verify checkbox in the left-of-text box
	local function boxChecked()
		if not pSrvChecked then return false end
		local okCk, _ = pcall(function() return cbR:exists(pSrvChecked, 0.88) end)
		return okCk and true or false
	end

	logLine("Server: tap Europe text (ensure selection)")
	clickMatch(mEU)
	pcall(function() wait(0.25) end)
	local isChecked = boxChecked()
	if not isChecked then
		logLine("Server: checkbox not yet set; tapping Europe again")
		clickMatch(mEU)
		pcall(function() wait(0.25) end)
		isChecked = boxChecked()
	end

	if not isChecked then
		logLine("Server: Europe checkbox not confirmed in left-of-text box; aborting OK")
		return false
	end

	-- Only when the checkbox is in the Europe row, press OK
	if pOk then
		local okOK, mOK = pcall(function() return FULL:exists(pOk, 1.0) end)
		if okOK and mOK then
			logLine("Server: tap OK (7b)")
			clickMatch(mOK)
			pcall(function() wait(0.4) end)
			return true
		else
			logLine("Server: OK button not found")
			return false
		end
	end
	return false
end

-- Minimal Stage01
local function runStage01Minimal()
	setHUD("Stage01: start")
	logLine("Stage01: start")
	setImagesPath()
	local FULL = nil
	local okReg, reg = pcall(function() return Region(0, 0, 448, 252) end)
	if okReg and reg then FULL = reg else logLine("Stage01: Region create failed"); setHUD("Region failed"); return end

	-- Flags for video/skip handling (declare early so helpers capture the same upvalues)
	local videoSkipped = false
	local softSkipClicked = false

	-- Patterns
	local p16 = makePattern("btn_16_or_older.png", 0.78)
	local pAll = makePattern("btn_click_all.png", 0.80)
	local pStart = makePattern("btn_game_start.png", 0.80)
	local pOk = makePattern("btn_ok.png", 0.78)
	local pSrvChecked = makePattern("srv_checkbox_checked.png", 0.85)
	local pEuText = makePattern("srv_europe_text.png", 0.90)
	local pTerms = makePattern("terms_anchor.png", 0.85)
	local pFbIcon = makePattern("facebook_icon_login_screen.png", 0.78)
	local pGuestIcon = makePattern("guest_icon_login_screen.png", 0.78)
	local pYesConfirm = makePattern("yes_after_selecting_guest_acc.png", 0.80)
	local pAd1 = makePattern("advertisement_at_entrance_1.png", 0.85)
	local pAd2 = makePattern("advertisement_at_entrance_2.png", 0.85)
	local pTouchStart = makePattern("touch_to_start.png", 0.86)
	local pTouchStartAlt = makePattern("touch_to_start_1.png", 0.86)
	local pSkip = makePattern("skip.png", 0.78)
	-- Global dialog skip anchors
	local pDialSX = makePattern("DialSkipSX.png", 0.86)
	local pDialDX = makePattern("DialSkipDX.png", 0.86)
	-- Nickname stage patterns
	local pEnterNameInput = makePattern("Input.png", 0.80)
	local pEnterNameDONE = makePattern("EnterNameDONE.png", 0.80)
	local pEnterNameOK = makePattern("EnterNameOK.png", 0.80)

	-- Regions
	local LOGIN_R = Region(math.floor(448*0.08), math.floor(252*0.12), math.floor(448*0.84), math.floor(252*0.74))
	local YES_R = Region(math.floor(448*0.25), math.floor(252*0.30), math.floor(448*0.50), math.floor(252*0.40))
	if DEBUG_VISUALS then
		pcall(function() LOGIN_R:highlight(0.06) end)
		pcall(function() YES_R:highlight(0.06) end)
	end

	-- Fallback sweep (from 055): progressive guest search, then Facebook+swipe
	local function tryLoginSweep()
		local sims = {0.80, 0.75, 0.70}
		local regions = {LOGIN_R, FULL}
		for _, sim in ipairs(sims) do
			if pGuestIcon then
				for _, r in ipairs(regions) do
					local okG, mG = pcall(function() return r:exists(Pattern("guest_icon_login_screen.png"):similar(sim), 0.4) end)
					if okG and mG then
						logLine("LOGIN Fallback: found guest at sim=" .. tostring(sim))
						clickMatch(mG)
						pcall(function() wait(0.6) end)
						return true
					end
				end
			end
			if pFbIcon then
				for _, r in ipairs(regions) do
					local okF, mF = pcall(function() return r:exists(Pattern("facebook_icon_login_screen.png"):similar(sim), 0.4) end)
					if okF and mF then
						logLine("LOGIN Fallback: found Facebook at sim=" .. tostring(sim) .. "; scrolling to guest")
						for i = 1, 8 do
							pcall(function() swipe(Location(224, 210), Location(224, 90)) end)
							pcall(function() wait(0.25) end)
							local okG2, mG2 = pcall(function() return LOGIN_R:exists(Pattern("guest_icon_login_screen.png"):similar(sim), 0.4) end)
							if okG2 and mG2 then
								clickMatch(mG2)
								pcall(function() wait(0.6) end)
								return true
							end
						end
					end
				end
			end
		end
		return false
	end

	-- Helper to check if a pattern exists within a timeout on FULL
	local function has(pattern, t)
		if not pattern then return false end
		local ok, res = pcall(function() return FULL:exists(pattern, t or 0.25) end)
		return ok and res and true or false
	end

	-- Anchor helper moved up so other helpers can use it safely

	-- Close entrance advertisements by clicking on the second anchor; repeat until none remain
	local function closeEntranceAds()
		if not (pAd1 and pAd2) then return end
		setHUD("Ads: closing")
		local lastCloseX, lastCloseY = nil, nil
		for k=1,4 do
			local anyFound = false
			local m2 = nil
			local ok2, found2 = pcall(function() return FULL:exists(pAd2, 0.5) end)
			if ok2 and found2 then m2 = found2; anyFound = true end
			local ok1, found1 = pcall(function() return FULL:exists(pAd1, 0.5) end)
			if ok1 and found1 then anyFound = true end
			if m2 then
				logLine("Ads: tap ad2 to close")
				-- capture coordinates before click
				pcall(function()
					local loc = (m2.getCenter and m2:getCenter()) or (m2.getTarget and m2:getTarget())
					if loc and loc.getX and loc.getY then lastCloseX, lastCloseY = loc:getX(), loc:getY() end
				end)
				clickMatch(m2)
				pcall(function() wait(0.3) end)
			else
				-- If ad2 not visible but ad1 seen, small pause and retry
				if anyFound then pcall(function() wait(0.3) end) end
			end
			-- Verify none remain
			local okR1 = pcall(function() return FULL:exists(pAd1, 0.4) end)
			local okR2 = pcall(function() return FULL:exists(pAd2, 0.4) end)
			if (not okR1) and (not okR2) then break end
		end
		-- last close coordinates captured locally; do not attach to Region object
	end

	-- Wait up to 35s after LOGIN Yes, checking every 5s; close ads if they appear; verify none remain at end
	local function waitForEntranceAds()
		if not (pAd1 and pAd2) then return end
		setHUD("Ads: waiting up to 35s")
		for i = 1, 7 do -- 7 * 5s = 35s
			local seenA1 = has(pAd1, 0.6)
			local seenA2 = has(pAd2, 0.6)
			logLine("Ads wait check #" .. tostring(i) .. ": ad1=" .. tostring(seenA1) .. ", ad2=" .. tostring(seenA2))
			if seenA1 and seenA2 then
				logLine("Ads: anchors present → closing")
				closeEntranceAds()
				break
			end
			pcall(function() wait(5.0) end)
		end
		-- Final verify that no ad anchors remain
		local finalA1 = has(pAd1, 0.6)
		local finalA2 = has(pAd2, 0.6)
		if finalA1 or finalA2 then
			logLine("Ads: anchors still present after 35s → closing once more")
			closeEntranceAds()
		end
		-- If ads cleared, tap Touch to Start by fixed coordinates
		local seenTouch = ((pTouchStart and has(pTouchStart, 0.6)) or (pTouchStartAlt and has(pTouchStartAlt, 0.6)))
		if seenTouch then
			logLine("TouchStart: anchor visible → tapping fixed point (54, 233)")
			pcall(function() click(Location(54, 233)) end)
			pcall(function() wait(0.2) end)
		else
			logLine("TouchStart: anchor not visible, skipping")
		end
	end

	-- Wait up to 8s for Skip to appear on video and click it
	local function waitForSkip()
		if not pSkip then return false end
		local sims = {0.86, 0.82, 0.78, 0.74}
		for i=1,16 do -- ~8s total
			for _, s in ipairs(sims) do
				local okSk, mSk = pcall(function() return FULL:exists(Pattern("skip.png"):similar(s), 0.18) end)
				if okSk and mSk then
					logLine("Video: Skip detected (sim=" .. tostring(s) .. ") → tapping")
					clickMatch(mSk)
					pcall(function() wait(0.2) end)
					videoSkipped = true
					return true
				end
			end
			pcall(function() wait(0.5) end)
		end
		logLine("Video: Skip not detected in wait window")
		return false
	end

	-- Nickname: paste-only entry and confirm
	local function enterNicknamePaste()
		setHUD("Nickname: paste")
		-- Generate 12-char nickname: at least 5 letters, fill rest with digits
		local function gen12()
			local t = os.time(); math.randomseed((t % 100000) + 321)
			local vowels = {"a","e","i","o","u","y"}
			local cons = {"b","c","d","f","g","h","j","k","l","m","n","p","r","s","t","v","w","z"}
			local letters = {}
			for i=1,5 do
				local c = cons[math.random(#cons)] .. vowels[math.random(#vowels)]
				letters[#letters+1] = c
			end
			local flat = table.concat(letters)
			flat = string.sub(flat, 1, 5) .. string.sub(flat, 6, 12) -- ensure enough length
			flat = string.gsub(flat, "[^a-z]", "a")
			flat = string.upper(string.sub(flat,1,1)) .. string.sub(flat,2)
			local need = 12 - #flat
			local digits = ""
			for i=1, math.max(need, 0) do digits = digits .. tostring(math.random(0,9)) end
			local nick = string.sub(flat .. digits, 1, 12)
			return nick
		end
		local nick = gen12()
		logLine("Nickname: generated '" .. tostring(nick) .. "'")
		-- focus input
		local okI, mI = pcall(function() return FULL:exists(pEnterNameInput, 1.2) end)
		local cx, cy = nil, nil
		if okI and mI then
			clickMatch(mI); pcall(function() wait(0.25) end)
			pcall(function()
				local loc = (mI.getCenter and mI:getCenter()) or (mI.getTarget and mI:getTarget())
				if loc and loc.getX and loc.getY then cx, cy = loc:getX(), loc:getY() end
			end)
		end
		-- Only typing method
		pcall(function() logLine("Nickname: type() only") end)
		pcall(function() type(nick) end)
		pcall(function() wait(0.25) end)
		-- confirm DONE then OK
		local function tapPat(pat, label)
			for i=1,10 do local okP, mP = pcall(function() return FULL:exists(pat, 0.3) end); if okP and mP then logLine("Nickname: tap "..label); clickMatch(mP); return true end; pcall(function() wait(0.2) end) end; return false
		end
		tapPat(pEnterNameDONE, "DONE")
		pcall(function() wait(0.25) end)
		tapPat(pEnterNameOK, "OK")
		pcall(function() wait(0.35) end)
		return true
	end

	-- Soft popup handler: closes entrance ads, taps Skip/OK when visible
	local function handleSoftPopups(currentStage)
		local handledAny = false
		-- Global dialog skip anchors (tap either side if present)
		if pDialSX or pDialDX then
			local sims = {0.90, 0.88, 0.86, 0.84}
			for _, s in ipairs(sims) do
				if pDialSX then
					local ok1, m1 = pcall(function() return FULL:exists(Pattern("DialSkipSX.png"):similar(s), 0.18) end)
					if ok1 and m1 then
						logLine("SoftPopups: DialogSkip SX detected (sim=" .. tostring(s) .. ") → tap")
						clickMatch(m1)
						pcall(function() wait(0.18) end)
						handledAny = true
						break
					end
				end
				if pDialDX then
					local ok2, m2 = pcall(function() return FULL:exists(Pattern("DialSkipDX.png"):similar(s), 0.18) end)
					if ok2 and m2 then
						logLine("SoftPopups: DialogSkip DX detected (sim=" .. tostring(s) .. ") → tap")
						clickMatch(m2)
						pcall(function() wait(0.18) end)
						handledAny = true
						break
					end
				end
			end
		end
		-- Entrance advertisements
		if pAd1 and pAd2 then
			local a1 = has(pAd1, 0.30)
			local a2 = has(pAd2, 0.30)
			if a1 and a2 then
				logLine("SoftPopups: entrance ads detected → closing")
				setHUD("Ads: closing")
				closeEntranceAds()
				handledAny = true
			end
		end
		-- Video Skip
		if pSkip then
			local okSk, mSk = pcall(function() return FULL:exists(pSkip, 0.2) end)
			if okSk and mSk then
				logLine("SoftPopups: Skip detected → tap")
				clickMatch(mSk)
				pcall(function() wait(0.2) end)
				videoSkipped = true
				softSkipClicked = true
				handledAny = true
			end
		end
		-- Generic OK (disabled on SERVER and NICKNAME stages to avoid premature confirm)
		if pOk and currentStage ~= "SERVER" and currentStage ~= "NICKNAME" then
			local okOk, mOk = pcall(function() return FULL:exists(pOk, 0.2) end)
			if okOk and mOk then
				logLine("SoftPopups: OK detected → tap")
				clickMatch(mOk)
				pcall(function() wait(0.2) end)
				handledAny = true
			end
		end
		return handledAny
	end

	-- No-priority detection helpers
	local STAGES = { "AGE_GATE", "SERVER", "LOGIN", "AD_ENTRANCE", "VIDEO", "NICKNAME" }
	local IDX = { AGE_GATE=1, SERVER=2, LOGIN=3, AD_ENTRANCE=4, VIDEO=5, NICKNAME=6 }

	-- FSM spec for logging/inspection
	local STAGE_SPEC_INFO = {
		AGE_GATE     = { next = {"SERVER"}, desc = "Age/Terms: 16+ → Click all → Game Start" },
		SERVER       = { next = {"LOGIN"}, desc = "Ensure Europe, tap OK" },
		LOGIN        = { next = {"AD_ENTRANCE", "VIDEO"}, desc = "Tap Guest, confirm Yes" },
		AD_ENTRANCE  = { next = {"VIDEO"}, desc = "Close entrance ads → Touch to start" },
		VIDEO        = { next = {"NICKNAME"}, desc = "Skip intro video" },
		NICKNAME     = { next = {}, desc = "Enter and confirm nickname" },
	}
	pcall(function()
		for name, spec in pairs(STAGE_SPEC_INFO) do
			local nxt = ""
			pcall(function() nxt = table.concat(spec.next or {}, ",") end)
			logLine("FSM: " .. tostring(name) .. " → [" .. tostring(nxt) .. "] :: " .. tostring(spec.desc))
		end
	end)
	local loginFbSeenConsec = 0
	local loginScrollAttempts = 0
	local loginFbConfirmed = false
	local loginCompleted = false
	local videoSkipped = false
	local softSkipClicked = false

	local function anchors(stage)
		if stage == "AGE_GATE" then return (has(p16) or has(pTerms) or has(pAll) or has(pStart)) end
		if stage == "SERVER" then return has(pOk,0.25) and (has(pEuText,0.30) or has(pSrvChecked,0.30)) end
		if stage == "LOGIN" then return (has(pGuestIcon) or has(pFbIcon)) end
		if stage == "AD_ENTRANCE" then
			return loginCompleted and ((has(pAd1) and has(pAd2)) or has(pTouchStart) or (pTouchStartAlt and has(pTouchStartAlt)))
		end
		if stage == "VIDEO" then return loginCompleted and has(pSkip) end
		if stage == "NICKNAME" then return loginCompleted and (
			(has(pEnterNameInput) or has(pEnterNameDONE) or has(pEnterNameOK))
		) end
		return false
	end

	-- Detect state once by evaluating all anchors; if multiple seen, choose earliest stage in flow
	local function detectStateNoPriority()
		local seen16   = has(p16, 0.6)
		local seenTerms= has(pTerms, 0.6)
		local seenAll  = has(pAll, 0.80)   -- stricter to avoid false positives
		local seenStart= has(pStart, 0.80) -- stricter to avoid false positives
		local seenOk   = has(pOk, 0.5)
		local seenEu   = has(pEuText, 0.5)
		local seenCk   = has(pSrvChecked, 0.5)
		local seenGuest= has(pGuestIcon, 0.6)
		local seenFb   = has(pFbIcon, 0.6)
		local seenAd1  = has(pAd1, 0.6)
		local seenAd2  = has(pAd2, 0.6)
		local seenTs   = pTouchStart and has(pTouchStart, 0.6)
		local seenTs2  = pTouchStartAlt and has(pTouchStartAlt, 0.6)
		local seenSkip = pSkip and has(pSkip, 0.6)
		local seenNick = (has(pEnterNameInput, 0.6) or has(pEnterNameDONE, 0.6) or has(pEnterNameOK, 0.6))

		logLine(string.format("Detect seen: 16=%s terms=%s all=%s start=%s ok=%s eu=%s ck=%s fb=%s guest=%s ad1=%s ad2=%s ts=%s ts2=%s skip=%s",
			tostring(seen16), tostring(seenTerms), tostring(seenAll), tostring(seenStart), tostring(seenOk), tostring(seenEu), tostring(seenCk), tostring(seenFb), tostring(seenGuest), tostring(seenAd1), tostring(seenAd2), tostring(seenTs), tostring(seenTs2), tostring(seenSkip)))

		-- Ordered selection by real flow
		if seen16 or seenTerms or seenAll or seenStart then return "AGE_GATE" end
		if seenOk and (seenEu or seenCk) then return "SERVER" end
		if (seenGuest or seenFb) then return "LOGIN" end
		if (seenAd1 and seenAd2) or seenTs or seenTs2 then return "AD_ENTRANCE" end
		if seenSkip then return "VIDEO" end
		if seenNick then return "NICKNAME" end
		return "UNKNOWN"
	end

	-- Robust detector for flickering 'Start' text (touch_to_start)
	local function detectTouchStartRobust()
		if not pTouchStart then return false end
		local sims = {0.94, 0.92, 0.90, 0.88, 0.86, 0.84, 0.82, 0.80}
		for i = 1, 20 do -- ~4s total (20 * 0.2)
			for _, s in ipairs(sims) do
				local ok1, m1 = pcall(function() return FULL:exists(Pattern("touch_to_start.png"):similar(s), 0.15) end)
				local ok2, m2 = pcall(function() return FULL:exists(Pattern("touch_to_start_1.png"):similar(s), 0.15) end)
				if (ok1 and m1) or (ok2 and m2) then
					logLine("TouchStart: detected (sim=" .. tostring(s) .. ") on probe #" .. tostring(i))
					return true
				end
			end
			pcall(function() wait(0.20) end)
		end
		logLine("TouchStart: not detected in robust scan window")
		return false
	end

	-- New: Self-locate on boot using a single snapshot
	local function detectEntryState()
		pcall(function() if usePreviousSnap then usePreviousSnap(true) end end)
		local seen16   = has(p16, 0.6)
		local seenTerms= has(pTerms, 0.6)
		local seenAll  = has(pAll, 0.80)
		local seenStart= has(pStart, 0.80)
		local seenOk   = has(pOk, 0.5)
		local seenEu   = has(pEuText, 0.5)
		local seenCk   = has(pSrvChecked, 0.5)
		local seenGuest= has(pGuestIcon, 0.6)
		local seenFb   = has(pFbIcon, 0.6)
		local seenAd1  = has(pAd1, 0.6)
		local seenAd2  = has(pAd2, 0.6)
		local seenTs   = pTouchStart and has(pTouchStart, 0.6)
		local seenTs2  = pTouchStartAlt and has(pTouchStartAlt, 0.6)
		local seenSkip = pSkip and has(pSkip, 0.6)
		local seenNick = (has(pEnterNameInput, 0.6) or has(pEnterNameDONE, 0.6) or has(pEnterNameOK, 0.6))
		local stage = "UNKNOWN"
		if seen16 or seenTerms or seenAll or seenStart then stage = "AGE_GATE"
		elseif seenOk and (seenEu or seenCk) then stage = "SERVER"
		elseif (seenGuest or seenFb) then stage = "LOGIN"
		elseif (seenAd1 and seenAd2) or seenTs or seenTs2 then stage = "AD_ENTRANCE"
		elseif seenSkip then stage = "VIDEO"
		elseif seenNick then stage = "NICKNAME" end
		logLine(string.format("Entry detect: stage=%s | seen: 16=%s terms=%s all=%s start=%s ok=%s eu=%s ck=%s fb=%s guest=%s ad1=%s ad2=%s ts=%s ts2=%s skip=%s",
			tostring(stage), tostring(seen16), tostring(seenTerms), tostring(seenAll), tostring(seenStart), tostring(seenOk), tostring(seenEu), tostring(seenCk), tostring(seenFb), tostring(seenGuest), tostring(seenAd1), tostring(seenAd2), tostring(seenTs), tostring(seenTs2), tostring(seenSkip)))
		pcall(function() if usePreviousSnap then usePreviousSnap(false) end end)
		return { stage = stage }
	end

	local function detectFrom(startIdx)
		for i = startIdx, #STAGES do
			if anchors(STAGES[i]) then return i end
		end
		return nil
	end

	-- Save a detection screenshot once
	pcall(function()
		local snap = "/sdcard/AnkuLua/screen_detect_" .. os.date("%Y%m%d_%H%M%S") .. ".png"
		FULL:save(snap)
		logLine("Detect: saved screen: " .. snap)
	end)

	-- Determine entry state once
	local entryRes = detectEntryState()
	local entry = entryRes and entryRes.stage or detectStateNoPriority()
	logLine("Entry state: " .. tostring(entry))
	-- Fast path: if starting on touch_to_start screen, ensure we see Start (robust) and tap fixed point
	if entry == "UNKNOWN" then
		local touchStart = detectTouchStartRobust()
		if touchStart then
			logLine("Entry: TouchStart screen → tapping (54, 233)")
			pcall(function() click(Location(54, 233)) end)
			pcall(function() wait(0.3) end)
		end
	end
	if entry == "AD_ENTRANCE" then
		-- When starting on ad screen, perform the full wait-and-close flow
		waitForEntranceAds()
		entry = detectStateNoPriority()
		logLine("Entry state (after ads): " .. tostring(entry))
		if entry == "UNKNOWN" then entry = "AGE_GATE" end
	end
	-- If starting already on VIDEO, act and proceed to NICKNAME through the loop
	if entry == "VIDEO" then
		setHUD("Video: Skip")
		loginCompleted = true
		local clicked = waitForSkip()
		if not clicked then
			local okSk, mSk = pcall(function() return FULL:exists(pSkip, 0.5) end)
			if okSk and mSk then clickMatch(mSk); pcall(function() wait(0.2) end) end
		end
		-- fall through into loop
	end
	local currentIdx = IDX[entry] or detectFrom(1) or IDX.AGE_GATE

	local maxLoops = 40
	local termsSwipesDone = 0
	for loop = 1, maxLoops do
		-- Allow jumping ahead if a later stage becomes visible
		local seenIdx = detectFrom(currentIdx)
		if seenIdx and seenIdx > currentIdx then currentIdx = seenIdx end
		-- If video already skipped or skip gone, jump to NICKNAME before logging
		if currentIdx == IDX.VIDEO then
			local skipVisibleNow = has(pSkip, 0.2)
			if (videoSkipped or (not skipVisibleNow)) then currentIdx = IDX.NICKNAME end
		end
		local st = STAGES[currentIdx]
		logLine("Stage01: state=" .. st .. " (loop " .. tostring(loop) .. ")")

		-- Quick soft popups pass each loop
		pcall(function()
			local did = handleSoftPopups(st)
			if did then wait(0.15) end
		end)
		if softSkipClicked then
			logLine("SoftPopups: Skip handled → advance to NICKNAME")
			currentIdx = IDX.NICKNAME
			softSkipClicked = false
		end

		if st == "AGE_GATE" then
			setHUD("Age/Terms")
			local okE16, m16 = pcall(function() return FULL:exists(p16, 0.6) end)
			if okE16 and m16 then
				clickMatch(m16)
				termsSwipesDone = 0
				pcall(function() wait(0.3) end)
			end
			-- Terms: scroll to 'Click all' and click
			if termsSwipesDone < 2 then
				pcall(function() swipe(Location(224, 210), Location(224, 70)) end)
				pcall(function() wait(0.2) end)
				termsSwipesDone = termsSwipesDone + 1
			end
			local okA, mA = pcall(function() return FULL:exists(pAll, 0.5) end)
			if okA and mA then
				clickMatch(mA)
				pcall(function() wait(0.3) end)
			end
			-- Game Start
			local okS, mS = pcall(function() return FULL:exists(pStart, 0.6) end)
			if okS and mS then
				setHUD("Tap: Game Start")
				clickMatch(mS)
				currentIdx = IDX.SERVER
				pcall(function() wait(0.3) end)
			else
				pcall(function() wait(0.15) end)
			end
		elseif st == "SERVER" then
			setHUD("Server: ensure Europe")
			local okServer = handleServerSelection(FULL, nil, pSrvChecked, pOk, nil)
			if okServer then
				currentIdx = IDX.LOGIN
				pcall(function() wait(0.2) end)
			else
				pcall(function() wait(0.2) end)
			end
		elseif st == "LOGIN" then
			setHUD("Login: Guest")
			local tapped = false
			-- First, confirm we're on the login screen by detecting Facebook icon once
			if not loginFbConfirmed then
				local okFConfirm, _ = pFbIcon and pcall(function() return FULL:exists(Pattern("facebook_icon_login_screen.png"):similar(0.80), 0.5) end) or false, nil
				if okFConfirm then
					loginFbConfirmed = true
					logLine("Login: Facebook anchor confirmed")
				else
					logLine("Login: waiting for Facebook anchor")
					pcall(function() wait(0.3) end)
				end
			else
				-- Anchor confirmed: proceed to find/tap Guest
				-- Quick direct check for guest on full screen
				local okG, mG = pGuestIcon and pcall(function() return FULL:exists(Pattern("guest_icon_login_screen.png"):similar(0.60), 0.5) end) or false, nil
				if okG and mG then
					logLine("Login: Guest visible → tap")
					clickMatch(mG); tapped = true; pcall(function() wait(0.4) end)
				else
					-- Perform swipe, and after every 2 swipes do a full-screen guest check
					loginScrollAttempts = loginScrollAttempts + 1
					logLine("Login: swipe down attempt #" .. tostring(loginScrollAttempts))
					pcall(function() swipe(Location(224, 210), Location(224, 60)) end)
					pcall(function() wait(0.50) end)
					if loginScrollAttempts % 2 == 0 then
						-- Save full-screen snapshot for debugging
						pcall(function()
							local ts = os.date("%H%M%S")
							local name = "screen_login_swipes_" .. tostring(loginScrollAttempts) .. "_" .. ts .. ".png"
							local path2 = "/sdcard/AnkuLua/" .. name
							FULL:save(path2)
							logLine("Login: saved snapshot: " .. path2)
						end)
						-- Thorough full-screen search with multiple similarities
						local sims2 = {0.90, 0.85, 0.80, 0.75, 0.70, 0.65}
						local found = false
						for _, s in ipairs(sims2) do
							local okG2, mG2 = pGuestIcon and pcall(function() return FULL:exists(Pattern("guest_icon_login_screen.png"):similar(s), 0.6) end) or false, nil
							if okG2 and mG2 then
								logLine("Login: Guest found on full-screen check (sim=" .. tostring(s) .. ") after " .. tostring(loginScrollAttempts) .. " swipes")
								clickMatch(mG2); tapped = true; found = true; break
							end
						end
						if not found then logLine("Login: Guest not found on full-screen check") end
					end
				end
				-- As a final fallback each loop, try the 055 sweep if not already tapped
				if (not tapped) then
					local didFallback = tryLoginSweep()
					if didFallback then tapped = true end
				end
			end
			if tapped and pYesConfirm then
				for j=1,10 do
					local okY, mY = pcall(function() return FULL:exists(pYesConfirm, 0.8) end)
					if okY and mY then logLine("Login: tap Yes confirm"); clickMatch(mY); pcall(function() wait(0.3) end); break end
					pcall(function() wait(0.2) end)
				end
				-- After Yes: mark login completed and handle Ads -> Start -> Video
				loginCompleted = true
				waitForEntranceAds()
				-- Start
				local onStart = (pTouchStart and has(pTouchStart, 0.6)) or (pTouchStartAlt and has(pTouchStartAlt, 0.6))
				if onStart then
					logLine("Post-Login: Start visible → tapping (54, 233)")
					pcall(function() click(Location(54, 233)) end)
					pcall(function() wait(0.3) end)
					-- Right after Start, wait for video Skip
					waitForSkip()
				end
				-- Video
				local onVideoSkip = pSkip and has(pSkip, 0.5)
				if onVideoSkip then
					logLine("Post-Login: Video Skip visible → tapping")
					local okSk, mSk = pcall(function() return FULL:exists(pSkip, 0.5) end)
					if okSk and mSk then
						clickMatch(mSk)
						pcall(function() wait(0.2) end)
						-- After skip, proceed to nickname stage
						currentIdx = IDX.NICKNAME
					end
				end
			end
			-- Leave LOGIN only after successful tap on Guest (tapped==true). Otherwise keep looping LOGIN
			-- After tapping Guest, do not break; let the loop advance to following stages
			if not tapped then pcall(function() wait(0.25) end) end
		elseif st == "AD_ENTRANCE" then
			setHUD("Ads/Start")
			closeEntranceAds()
			-- Touch to start inside AD_ENTRANCE
			local onStart = (pTouchStart and has(pTouchStart, 0.6)) or (pTouchStartAlt and has(pTouchStartAlt, 0.6))
			if onStart then
				logLine("AD_ENTRANCE: Start visible → tapping (54, 233)")
				pcall(function() click(Location(54, 233)) end)
				pcall(function() wait(0.3) end)
			end
			currentIdx = IDX.VIDEO
		elseif st == "VIDEO" then
			setHUD("Video: Skip")
			-- If Skip not on screen anymore or already skipped, jump ahead without waiting
			local skipVisible = has(pSkip, 0.3)
			if skipVisible and (not videoSkipped) then
				local clicked = waitForSkip()
				if not clicked then
					local okSk, mSk = pcall(function() return FULL:exists(pSkip, 0.5) end)
					if okSk and mSk then clickMatch(mSk); pcall(function() wait(0.2) end); videoSkipped = true end
				end
			end
			-- proceed to nickname immediately after handling skip
			currentIdx = IDX.NICKNAME
			pcall(function() wait(0.2) end)
		elseif st == "NICKNAME" then
			setHUD("Nickname: stage")
			enterNicknamePaste()
			setHUD("Stage01: nickname done")
			return
		else
			-- Recovery for UNKNOWN: light highlight and short wait
			highlightScan(FULL)
			pcall(function() wait(0.25) end)
		end
	end

	setHUD("Stage01: done")
	logLine("Stage01: end")
end

-- Configuration flags
local KEEP_ALIVE_AFTER_STAGE = true

local function main()
	__early("BOOT:M1 entering main")
	initLogger()
	if chosenLogPath then __early("BOOT:M1.1 log " .. tostring(chosenLogPath)) end
	logLine("BOOT started")
	showBootHUD()
	-- Optional debug screenshot of full screen
	pcall(function()
		-- removed boot-time screenshot save to avoid missing path issues
	end)
	logLine("BOOT finished")
	-- Run stage 01 minimal after boot
	runStage01Minimal()
	-- Keep script alive optionally
	if KEEP_ALIVE_AFTER_STAGE then
		setHUD("Waiting next step... (STOP to exit)")
		while true do
			if isStopRequested and isStopRequested() then
				setHUD("Stop requested. Exiting...")
				break
			end
			local okWait, errWait = pcall(function() wait(0.5) end)
			if not okWait then
				local msg = tostring(errWait or "")
				if string.find(msg, "User Abort", 1, true) or string.find(msg, "UserAbort", 1, true) then
					setHUD("Stop requested. Exiting...")
					break
				else
					error(errWait)
				end
			end
		end
	else
		setHUD("Stage01 done. Exiting...")
		pcall(function() wait(0.6) end)
	end
end

__early("BOOT:M0.9 before main")
-- Wrap main with xpcall to log fatal errors, then rethrow so AnkuLua shows the window
local function __fatal_handler(err)
    -- Suppress noisy FATAL logs for user-initiated aborts
    local errStr = tostring(err or "")
    local isUserAbort = (string.find(errStr, "User Abort", 1, true) ~= nil) or (string.find(errStr, "UserAbort", 1, true) ~= nil)

    local trace = nil
    pcall(function()
        if debug and debug.traceback then trace = debug.traceback("", 2) end
    end)
    local msg = (isUserAbort and "[INFO] User Abort") or ("[FATAL] " .. errStr)
    if (not isUserAbort) and trace and trace ~= "" then msg = msg .. "\n" .. trace end
    -- Write via normal logger
    pcall(function() logLine(msg) end)
    -- Hard-write to files as fallback to ensure persistence
    local function hardWrite(path)
        pcall(function()
            local f = io.open(path, "a")
            if f then f:write(msg .. "\n"); f:flush(); f:close() end
        end)
    end
    if chosenLogPath then hardWrite(chosenLogPath) end
    if __early_logpath then hardWrite(__early_logpath) end
    if not isUserAbort then hardWrite("/sdcard/AnkuLua/log_stage01_guest_fatal.log") end
    return err
end

local ok_main, err_main = xpcall(main, __fatal_handler)
if not ok_main then
    local errStr = tostring(err_main or "")
    local isUserAbort = (string.find(errStr, "User Abort", 1, true) ~= nil) or (string.find(errStr, "UserAbort", 1, true) ~= nil)
    if not isUserAbort then
        -- Re-throw so AnkuLua displays its native error dialog for real errors
        error(err_main)
    end
end

pcall(function()
	if logFile then logFile:flush(); logFile:close(); logFile = nil end
	if __early_logfile then __early_logfile:flush(); __early_logfile:close(); __early_logfile = nil end
end)