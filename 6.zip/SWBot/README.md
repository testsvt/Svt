SWBot for Summoners War

Paths on device (MuMu shared folder):

- Scripts: `/storage/emulated/0/$MuMuSharedFolder/SWBot/scripts/`
- Images: `/storage/emulated/0/$MuMuSharedFolder/SWBot/images/swbot_main/`


Screen settings:

- Resolution: 448x252
- DPI: 160
- Language: English
- Emulator: MuMu Player 6 x32



